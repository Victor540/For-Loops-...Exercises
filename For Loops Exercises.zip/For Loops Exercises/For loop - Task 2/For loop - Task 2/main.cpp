//
//  main.cpp
//  For loop - Task 2
//  Using a for loop write a program to compute the sum of number between 20 and 25.
//
//  Created by Victor Mwendwa on 11/16/21.
//

#include <iostream>
using namespace std;

int main(){
int number;
int sum=0;
    
    
    for(number=20; number<=25; number++)
    sum = sum+number;

    
    cout<< "Total sum of numbers between 20 and 25 is:\n"<<sum;


}
