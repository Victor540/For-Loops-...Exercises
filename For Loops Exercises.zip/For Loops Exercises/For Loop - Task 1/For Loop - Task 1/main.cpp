//
//  main.cpp
//  For Loop - Task 1
//  Using the for loop, write a program that outputs the numbers; 12,14,16,18,20,22,24,26,28.
//
//  Created by Victor Mwendwa 137368 on 11/18/21.
//

#include <iostream>
using namespace std;

int main(){
    int number;
    
    for(number=12; number<=28; number= number + 2)
    cout<< "\n"<<number;
}
